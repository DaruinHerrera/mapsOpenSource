<?php
class maps_widgetControllerUms extends controllerUms {

}