<style type="text/css">
	.umsAdminMainLeftSide {
		width: 56%;
		float: left;
	}
	.umsAdminMainRightSide {
		width: <?php echo (empty($this->optsDisplayOnMainPage) ? 100 : 40)?>%;
		float: left;
		text-align: center;
	}
	#umsMainOccupancy {
		box-shadow: none !important;
	}
</style>
<section>
	<div class="supsystic-item supsystic-panel">
		<div id="containerWrapper">
			<?php _e('Main page Go here!!!!', UMS_LANG_CODE)?>
		</div>
		<div style="clear: both;"></div>
	</div>
</section>